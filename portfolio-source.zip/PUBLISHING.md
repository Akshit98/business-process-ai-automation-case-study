# Publishing

Status: public repository created; website deployment pending verification.

## GitHub Pages

Create a public repository named `business-process-ai-automation-case-study`, upload this repository's contents, and select **Settings → Pages → Source → GitHub Actions**. The included workflow publishes only `dist/` on pushes to `main`, or on a manual run.

After a successful deployment, use the URL shown in Pages settings as the recruiter link. Add the verified repository URL to the website's evidence link and README. Do not present an expected URL as live before checking it.

Reference: [GitHub Pages publishing configuration](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).
