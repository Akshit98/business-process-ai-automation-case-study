# Consulting Client Delivery Workflow Optimization & AI Automation

**Akshit Didla · Independent portfolio project · 2026**

A website-first case study of a consulting-firm process from lead intake through billing. The design focuses on complete CRM records, approved handoffs, proposed HubSpot-to-Asana automation, and human review of AI drafts.

[View repository](https://github.com/Akshit98/business-process-ai-automation-case-study) · [Download executive summary](case-study/Akshit_Didla_Executive_Summary.pdf)

## Project status

Analysis and design complete. Website built. Production workflow not implemented. No measured business results are claimed. Public hosting status is recorded in `PUBLISHING.md`.

## The problem

The supplied scenario includes referrals, LinkedIn and website enquiries, discovery calls, inconsistent HubSpot logging, proposals and agreements, Asana setup, consultant assignment, delivery communication, time tracking and billing. Inconsistent CRM logging is the explicit problem; other gaps and root causes are hypotheses to validate.

## Proposed solution

1. Standardize required fields and named owners.
2. Gate project creation on signed and approved scope.
3. Create one linked project per approved handoff, with recovery for failures.
4. Use AI for reviewed drafts; retain human approval of commitments and billing.
5. Establish baseline measures before evaluating a limited pilot.

## Explore the evidence

- [Full process analysis](analysis/full-case-study.md)
- [Current-state workflow](docs/current-state-workflow.svg) / [Future-state workflow](docs/future-state-workflow.svg)
- [Gap analysis](analysis/gap-analysis.md) / [Root-cause hypotheses](analysis/root-cause-analysis.md)
- [Automation opportunities](automation/automation-opportunities.md) / [AI use cases](automation/ai-use-cases.md)
- [KPI framework](kpi-framework/metrics.md)
- [Implementation roadmap](analysis/implementation-roadmap.md)
- [Risks and controls](analysis/risks-and-controls.md)
- [Case study PDF](case-study/Akshit_Didla_Workflow_Case_Study.pdf) / [Executive summary](case-study/Akshit_Didla_Executive_Summary.pdf)

## Website

The website is plain HTML, CSS and JavaScript in `dist/`. It has no external dependencies, analytics, login, data collection or API credentials. Open `dist/index.html` locally, or serve that directory with a static HTTP server. A GitHub Pages workflow is included.

## Evidence boundary

Independent case-study project using a simulated consulting-operations setting adapted from an anonymized assessment outline. The original transcript and operating data were unavailable. Proposed targets are illustrative, and acceptance tests are planned rather than executed. No company employment, client engagement or endorsement is implied. Prepared with AI assistance.

## Updating the project

Edit the site in `dist/` and the corresponding supporting analysis files. Keep target labels and evidence boundaries intact. Update PDFs when the underlying analysis changes. Document substantive revisions in `CHANGELOG.md`; do not fabricate retrospective activity or implementation results.
