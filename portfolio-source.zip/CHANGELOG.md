# Changelog

## 2026-09-11

- Adapted the document case study into an anonymized website-first portfolio.
- Added workflow views and organized supporting analysis files.
- Preserved the distinction between scenario facts, hypotheses, proposed targets and unexecuted tests.
